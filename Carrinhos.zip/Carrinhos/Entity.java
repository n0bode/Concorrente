/****************************************************************
* Autor: Paulo Rodrigues Camacan    
* Matricula: 201810829
* Inicio: 15/11/2019
* Ultima alteracao: 23/11/2019
* Nome: Entity
* Funcao: Sao os carrinhos
****************************************************************/
import java.awt.Graphics2D;
import java.awt.Color;

public class Entity implements Runnable{
	private float speed;
  private Path path;
  private Vec position;
  private float angle;
  private float time;
  private float prev;
  private float prevRot;
  private float direction;
  private ITrigger onEnterTrigger;
  private boolean started = true;

  private final Animation anim;
  private final Color color;

  public Entity(int s0, int s1, Color color){
    this.anim = new Animation(Icons.SPRITE, 16);
    this.anim.setFrameInterval(s0, s1);
    this.color = color;
    this.position = new Vec(0, 0);
    this.speed = 1;
  }

  public void addEnterTrigger(ITrigger event){
    this.onEnterTrigger = event;
  }

  public void setSpeed(float speed){
    this.speed = speed;
  }

  public void setDirection(float dir){
    this.direction = (dir > 0 ? 1 : -1);
  }

  public void setPath(Path path){
    this.path = path;
  }

  public Path getPath(){
    return this.path;
  }
  public float move(){
    prev = time;
    time += (this.speed * this.direction) / 1000f;
    position = path.move(started ? time : prev, time, onEnterTrigger);

    if (Math.abs(time - prevRot) >= 0.001f){
      Vec prevPosition = path.lerp(prevRot);
      Vec dif = position.sub(prevPosition);
      angle = (float)(Math.atan2(dif.y(), dif.x()) / Math.PI) * 180f;
      prevRot = prev;
    }
    started = false;
    return time;
  }


  @Override
  public void run(){
    try{
      while(true){
        this.move();
        Thread.sleep(Const.TICK);
      }
    }catch(Exception e){
      e.printStackTrace();
    }
  }

  public void draw(Graphics2D g){
    if(path == null || position == null)
      return;

    path.draw(g, color);
    anim.draw(g, position.x(), position.y(), 38, 38, 90 + angle);
  }
}
