/****************************************************************
* Autor: Paulo Rodrigues Camacan    
* Matricula: 201810829
* Inicio: 15/10/2019
* Ultima alteracao: 23/10/2019
* Nome: ITrigger
* Funcao: Interface para chama o callback dos gatilhos
****************************************************************/
public interface ITrigger{
  void onEnterTrigger(String name);
}