`javac *.java && java Principal && rm *.class`
